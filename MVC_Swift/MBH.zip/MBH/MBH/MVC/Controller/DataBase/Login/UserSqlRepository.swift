//
//  UserSqlRepository.swift
//  MBH
//
//  Created by tunv on 7/24/18.
//  Copyright © 2018 tunv. All rights reserved.
//

import Foundation
import RealmSwift
class UserSqlRepository: BaseSqlRepository<EZUserLocalModel> {
    
    
}
