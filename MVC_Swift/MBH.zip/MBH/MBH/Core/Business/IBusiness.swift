//
//  IBusiness.swift
//  MBH
//
//  Created by tunv on 7/26/18.
//  Copyright © 2018 tunv. All rights reserved.
//

import Foundation
protocol IBusiness {
    func doSomeThing()
}
