//
//  ILocalModel.swift
//  MBH
//
//  Created by tunv on 7/25/18.
//  Copyright © 2018 tunv. All rights reserved.
//

import Foundation
protocol ILocalModel {
    func getLocalId() -> String
}

